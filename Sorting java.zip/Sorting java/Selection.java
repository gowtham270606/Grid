import java.util.*;
class Selection{
	public static void main(String[] args){
		int arr[]={45,34,23,56,88,90};
		int n=arr.length;
		for(int i=0;i<n;i++){
			int min=arr[i];
			int min_in=i;
			for(int j=i+1;j<n;j++){
			     if(arr[j]<min){
				min=arr[j];
				min_in=j;
			     }
			}
			int temp=arr[i];
			arr[i]=arr[min_in];
			arr[min_in]=temp;
			
		}	
		for(int i=0;i<n;i++){
			System.out.print(" " + arr[i]);
 		}
	}
}