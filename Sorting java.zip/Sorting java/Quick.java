import java.util.*;
class Quick{
	public static int pat(int[] arr,int low,int high){
		int i=low;
		int j=high;
		int pivot=arr[low];
		while(i<j){
			while(i<=high&&arr[i]<=pivot){
				i++;
			}
			while(j>=low&&arr[j]>pivot){
				j--;
			}
			if(i<j){
				swap(arr,i,j);
			}
		}
		swap(arr,j,low);
		return j;

	}
	public static void swap(int[] arr,int i,int j){
		int temp=arr[i];
		arr[i]=arr[j];
		arr[j]=temp;
	}
	public static void quicksort(int[] arr,int low,int high){
		if(low<high){
			int pivot=pat(arr,low,high);
			quicksort(arr,low,pivot-1);
			quicksort(arr,pivot+1,high);
		}		
	}
	public static void main(String[] args){
		int arr[]={23,2,12,34,24,23,90};
		quicksort(arr,0,arr.length-1);
		System.out.println(Arrays.toString(arr));
	}
}